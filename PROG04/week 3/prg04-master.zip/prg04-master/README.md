# prg04
Typescript oefeningen voor MT-PRG01-4

## Week 1
Pixel Aquarium Javascript

## Week 2
Pixel Aquarium Typescript

## Week 3
- Pong in Typescript
- Code voor Keyboard Input
- Code voor Collision Detection

## Week 4
- Composition

## Snippets
- Leeg startproject voor VS Code
- Code snippets voor CSS en javascript
- Links naar tutorials!