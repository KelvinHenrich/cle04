/// <reference path="message.ts"/>

class Main {
    constructor() {
       let demomessage = new Message();
    }
} 

// hier starten we de applicatie
window.addEventListener("load", function() {
    new Main();
});