## Leeg VS Code Typescript project

Dit is een leeg VS Code project met de volgende instellingen:
- DIST folder bevat de website : html, css en javascript
- DEV folder bevat de typescript files
- tsconfig.json bevat instellingen voor het compileren naar javascript
- tasks.json bevat het 'build' commando. Dit voer je uit met CMD+SHIFT+B
