window.addEventListener("load", startApp);


var kartsFinished = 0;


function startApp() {

	// here we define the start button
	TweenLite.set("#start", {y:50});
	TweenLite.set(".kart", {x:50});

}