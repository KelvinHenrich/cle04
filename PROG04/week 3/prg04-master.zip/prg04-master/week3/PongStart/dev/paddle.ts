class Paddle {
    
    constructor() {
        
    }
    
    public move(){
        
    }
}