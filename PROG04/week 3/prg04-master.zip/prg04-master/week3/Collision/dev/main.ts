window.addEventListener("load", function() {
    new Game();
});